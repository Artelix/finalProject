package controller;

import dao.model.product.ProductCategory;
import org.junit.*;
import org.mockito.*;
import org.mockito.MockitoAnnotations;
import service.IProductCategoryService;
import service.IProductService;
import service.model.ProductCategoryViewModel;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class ProductControllerTest {
    @InjectMocks
    private ProductController productController;

    @Mock
    private IProductCategoryService productCategoryService;

    @Mock
    private IProductService productService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getProductsCategories() {
        List<ProductCategoryViewModel> productCategoriesExpected = new ArrayList<>();
        productCategoriesExpected.add(new ProductCategoryViewModel(1L, "Computers"));
        productCategoriesExpected.add(new ProductCategoryViewModel(2L, "Video Games"));

        when(productCategoryService.getList()).thenReturn(productCategoriesExpected);

        List<ProductCategoryViewModel> productCategoriesActual = productController.getProductsCategories();

        verify(productCategoryService).getList();

        Assert.assertEquals(productCategoriesActual, productCategoriesExpected);
    }

    @Test
    public void searchProducts() {
    }

    @Test
    public void getProductDetails() {
    }

    @Test
    public void getProductsByCategory() {
    }

    @Test
    public void getProductsByPrices() {
    }

    @Test
    public void getProductsByRating() {
    }
}