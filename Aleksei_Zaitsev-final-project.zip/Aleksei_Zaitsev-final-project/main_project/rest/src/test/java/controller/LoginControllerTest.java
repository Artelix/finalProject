package controller;

import model.AuthRequest;
import org.junit.*;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import service.IUserService;
import util.JwtUtil;

import static org.mockito.Mockito.*;

public class LoginControllerTest {
    private AuthRequest authRequest;

    @InjectMocks
    private LoginController loginController;

    @Mock
    private IUserService userService;

    @Mock
    private JwtUtil jwtUtil;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Before
    public void setUp() {
        authRequest = new AuthRequest();
        authRequest.setLogin("admin");
        authRequest.setPassword("admin");
    }

    @Test
    public void login_OK() {
        Long userId = 1L;
        ResponseEntity<String> authResponseExpected = new ResponseEntity<String>("authToken", HttpStatus.OK);

        when(userService.getUser(authRequest.getLogin(), authRequest.getPassword())).thenReturn(userId);
        when(jwtUtil.createJWT(any(String.class), any(String.class), any(String.class), any(long.class), eq(userId))).thenReturn("authToken");

        ResponseEntity<String> authResponseActual = loginController.login(authRequest);

        verify(userService).getUser(authRequest.getLogin(), authRequest.getPassword());

        verify(jwtUtil).createJWT(any(String.class), any(String.class), any(String.class), any(long.class), eq(userId));

        Assert.assertEquals(authResponseActual, authResponseExpected);
    }

    @Test
    public  void login_UNAUTHORIZED(){
        Long userId = null;
        ResponseEntity<String> authResponseExpected = new ResponseEntity<String>("access denied", HttpStatus.UNAUTHORIZED);

        when(userService.getUser(authRequest.getLogin(), authRequest.getPassword())).thenReturn(userId);

        ResponseEntity<String> authResponseActual = loginController.login(authRequest);

        verify(userService).getUser(authRequest.getLogin(), authRequest.getPassword());

        Assert.assertEquals(authResponseActual, authResponseExpected);
    }
}