package model;

public class GetProductsByRatingRequest {
    private Integer lowRating;

    private Integer highRating;

    public Integer getLowRating() {
        return lowRating;
    }

    public void setLowRating(Integer lowRating) {
        this.lowRating = lowRating;
    }

    public Integer getHighRating() {
        return highRating;
    }

    public void setHighRating(Integer highRating) {
        this.highRating = highRating;
    }
}
