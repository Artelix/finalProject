package filter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import service.ProductService;
import util.JwtUtil;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AuthFilter implements Filter {
    final Logger logger = Logger.getLogger(AuthFilter.class);
    private String excludedUrlPattern;

    @Autowired
    JwtUtil jwtUtil;

    public AuthFilter() {
    }

    @Override
    public void init(FilterConfig fConfig) {
        excludedUrlPattern = fConfig.getInitParameter("excludedUrlPattern");
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, fConfig.getServletContext());
    }

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException {
        try {
            String uri = ((HttpServletRequest) request).getRequestURI();
            if (uri.startsWith(excludedUrlPattern)) {
                chain.doFilter(request, response);
                return;
            }
            String jwtToken = ((HttpServletRequest) request).getHeader("auth-token");
            Integer userId = jwtUtil.parseJWT(jwtToken);
            request.setAttribute("userId", userId);
            chain.doFilter(request, response);
        } catch (Exception ex) {
            logger.error("Filter ERROR " + ex);
            response.getWriter().println("access denied");
            ((HttpServletResponse) response).setStatus(HttpStatus.UNAUTHORIZED.value());
        }
    }
}
