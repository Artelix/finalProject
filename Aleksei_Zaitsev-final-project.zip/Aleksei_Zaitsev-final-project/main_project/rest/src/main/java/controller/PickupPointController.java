package controller;

import model.AddPickupPointRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.IPickupPointService;
import service.model.PickupPointViewModel;

import java.util.List;

@RestController
@RequestMapping(value = "/pickup")
public class PickupPointController {
    @Autowired
    private IPickupPointService pickupPointService;

    @GetMapping(value = "/getPickupPoints")
    public List<PickupPointViewModel> getPickupPoints() {
        return pickupPointService.getAllPoints();
    }

    @PostMapping(value = "/addPickupPoint")
    public Boolean addPickupPoint(@RequestAttribute Long userId, @RequestBody AddPickupPointRequest request) {
        return pickupPointService.addPickupPoint(
                request.getAddress(),
                request.getLatitude(),
                request.getLongitude(),
                request.getDescription());
    }

    @PostMapping(value = "/deletePickupPoint")
    public Boolean deletePickupPoint(@RequestAttribute Long userId, @RequestBody Long id) {
        return pickupPointService.deletePickupPoint(id);
    }
}
