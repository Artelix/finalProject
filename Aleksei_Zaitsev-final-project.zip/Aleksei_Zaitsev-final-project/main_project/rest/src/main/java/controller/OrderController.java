package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.IOrderService;
import service.model.StatusViewModel;

import java.util.List;

@RestController
@RequestMapping(value = "/order")
public class OrderController {
    @Autowired
    private IOrderService orderService;



    @PostMapping(value = "/createOrder")
    public Boolean createOrder(@RequestBody Long userId) {
        return orderService.createOrder(userId);
    }

    @PostMapping(value = "/addStatus")
    public Boolean addStatus(@RequestBody String statusName) {
        return orderService.addStatus(statusName);
    }

    @PostMapping(value = "/deleteStatus")
    public Boolean deleteStatus(@RequestBody Long statusId) {
        return orderService.deleteStatus(statusId);
    }

    @GetMapping(value = "/getStatusList")
    public List<StatusViewModel> getStatusList() {
        return orderService.getStatusList();
    }

}
