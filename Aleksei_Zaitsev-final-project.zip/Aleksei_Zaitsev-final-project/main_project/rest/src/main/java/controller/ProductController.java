package controller;

import model.AddProductRequest;
import model.GetProductsByPricesRequest;
import model.GetProductsByRatingRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.IProductCategoryService;
import service.IProductService;
import service.model.ProductCategoryViewModel;
import service.model.ProductViewModel;

import java.util.List;

@RestController
@RequestMapping(value = "/products")
public class ProductController {
    @Autowired
    private IProductCategoryService productCategoryService;

    @Autowired
    private IProductService productService;

    @PostMapping(value = "/searchProducts")
    public List<ProductViewModel> searchProducts(@RequestBody String word){
        return productService.search(word);
    }

    @PostMapping(value="/addProduct")
    public Boolean addProduct(@RequestBody AddProductRequest request){
        return productService.addProduct(
                request.getName(),
                request.getQuantity(),
                request.getPrice(),
                request.getImagePath(),
                request.getDetails(),
                request.getCategoryId());
    }

    @PostMapping(value="/deleteProduct")
    public Boolean deleteProduct(@RequestBody Long productId){
        return productService.deleteProduct(productId);
    }


    @PostMapping(value="/getProductsByPrices")
    public List<ProductViewModel> getProductsByPrices(@RequestBody GetProductsByPricesRequest request){
        return productService.getListByPrices(request.getLowPrice(), request.getHighPrice());
    }

    @PostMapping(value="/getProductsByRating")
    public List<ProductViewModel> getProductsByRating(@RequestBody GetProductsByRatingRequest request){
        return productService.getListByRating(request.getLowRating(), request.getHighRating());
    }
    @GetMapping(value="/getProductsCategories")
    public List<ProductCategoryViewModel> getProductsCategories(){
        return productCategoryService.getList();
    }

    @GetMapping(value = "/getProductsByCategory/{productCategoryId}")
    public List<ProductViewModel> getProductsByCategory(@PathVariable Long productCategoryId) {
        return productService.getListByCategory(productCategoryId);
    }

    @GetMapping(value="getProductDetails/{productId}")
    public ProductViewModel getProductDetails(@PathVariable Long productId){
        return productService.getDetails(productId);
    }
}
