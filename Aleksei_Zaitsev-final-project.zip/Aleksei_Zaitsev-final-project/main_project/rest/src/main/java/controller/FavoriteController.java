package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.IFavoriteService;
import service.model.FavoriteViewModel;

import java.util.List;

@RestController
@RequestMapping(value = "/favorite")
public class FavoriteController {
    @Autowired
    private IFavoriteService favoriteService;

    @GetMapping(value = "/getFavorite")
    public List<FavoriteViewModel> getUserFavorite(@RequestAttribute Long userId) {
        return favoriteService.getFavoriteProducts(userId);
    }

    @PostMapping(value = "/addToFavorite")
    public Boolean addToFavorite(@RequestAttribute Long userId, @RequestBody Long productId) {
        return favoriteService.addToFavorites(userId, productId);
    }

    @PostMapping(value = "/deleteFromFavorite")
    public Boolean deleteFromFavorites(@RequestAttribute Long userId, @RequestBody Long favoriteProductId) {
        return favoriteService.deleteFromFavorites(favoriteProductId);
    }
}
