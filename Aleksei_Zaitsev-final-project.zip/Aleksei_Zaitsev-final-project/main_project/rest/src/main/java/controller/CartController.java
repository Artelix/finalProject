package controller;

import model.AddToCartRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.ICartService;
import service.model.CartItemViewModel;

import java.util.List;

@RestController
@RequestMapping(value = "/cart")
public class CartController {
    @Autowired
    private ICartService cartService;

    @GetMapping(value = "/getUserCart")
    public List<CartItemViewModel> getUserCart(@RequestAttribute Long userId) {
        return cartService.getCart(userId);
    }

    @PostMapping(value = "/addToCart")
    public Boolean addToCart(@RequestAttribute Long userId, @RequestBody AddToCartRequest request) {
        return cartService.addToCart(userId, request.getProductId(), request.getQuantity());
    }

    @PostMapping(value = "/deleteFromCart")
    public Boolean deleteFromCart(@RequestBody Long cartItemId) {
        return cartService.deleteFromCart(cartItemId);
    }

}
