package controller;

import io.swagger.annotations.*;
import model.AuthRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import service.IUserService;
import util.JwtUtil;

import javax.ws.rs.Path;

@RestController
public class LoginController {
    @Autowired
    private IUserService userService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody AuthRequest request) {
        Long userId = userService.getUser(request.getLogin(), request.getPassword());

        if (userId != null) {
            String jwtToken = jwtUtil.createJWT(java.util.UUID.randomUUID().toString(), "rest", "login", 300000000, userId);
            return new ResponseEntity<String>(jwtToken, HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("access denied", HttpStatus.UNAUTHORIZED);
        }
    }
}
