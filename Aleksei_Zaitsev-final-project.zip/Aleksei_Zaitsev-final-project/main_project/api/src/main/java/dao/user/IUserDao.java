package dao.user;

import dao.IAbstractDao;
import exception.DBException;
import dao.model.user.User;

public interface IUserDao extends IAbstractDao<User, Long> {

    User getUser(String login, String password) throws DBException;
}
