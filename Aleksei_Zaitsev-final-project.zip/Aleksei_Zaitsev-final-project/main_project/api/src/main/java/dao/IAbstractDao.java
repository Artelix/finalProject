package dao;

import exception.DBException;

import java.io.Serializable;
import java.util.List;

public interface IAbstractDao<T, PK extends Serializable> {

    PK create(T entity) throws DBException;

    Boolean persist(T entity) throws DBException;

    T read(PK id) throws DBException;

    Boolean update(T entity) throws DBException;

    Boolean delete(PK id) throws DBException;

    List<T> findAll() throws DBException;

    Boolean checkForUnique(String columnName, String value) throws DBException;
}
