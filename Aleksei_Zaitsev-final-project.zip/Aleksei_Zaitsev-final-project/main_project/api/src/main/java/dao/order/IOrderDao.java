package dao.order;

import dao.IAbstractDao;
import dao.model.order.Order;

public interface IOrderDao extends IAbstractDao<Order, Long> {
}
