package dao.model.comment;

public enum ProductCommentType {
    COMMENT,
    REVIEW
}
