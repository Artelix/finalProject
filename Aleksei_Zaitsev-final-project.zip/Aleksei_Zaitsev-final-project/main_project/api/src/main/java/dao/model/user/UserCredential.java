package dao.model.user;

import javax.persistence.*;

@Entity
@Table(name = "user_creds")
public class UserCredential {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String login;

    @Column
    private String password;

    @OneToOne(mappedBy = "credential")
    private User user;

    public UserCredential() {
    }
}
