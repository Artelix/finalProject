package dao.pickup_point;

import dao.IAbstractDao;
import dao.model.PickupPoint;

public interface IPickupPointDao extends IAbstractDao<PickupPoint, Long> {
}
