package dao.favorite;

import dao.IAbstractDao;
import exception.DBException;
import dao.model.favorite.FavoriteProduct;

import java.util.List;

public interface IFavoriteProductDao extends IAbstractDao<FavoriteProduct, Long> {
    List<FavoriteProduct> getFavoriteProducts(Long userId) throws DBException;

    Boolean checkForUnique(Long userId, Long productId) throws DBException;
}
