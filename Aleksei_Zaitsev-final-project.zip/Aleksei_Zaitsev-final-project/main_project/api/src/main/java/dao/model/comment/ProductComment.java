package dao.model.comment;

import dao.model.product.Product;

import javax.persistence.*;

@Entity
@Table(name = "product_comments")
public class ProductComment extends BaseComment {

    @Column
    private ProductCommentType type;

    @ManyToOne
    @JoinColumn(name = "productId")
    private Product product;

    public ProductComment() {
    }
}
