package dao.model.user;

import dao.model.cart.CartItem;
import dao.model.favorite.FavoriteProduct;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    @Enumerated(EnumType.STRING)
    private UserRole role;

    @Column
    private String name;

    @Column
    private String imagePath;

    @OneToOne
    @JoinColumn(name = "id")
    private UserCredential credential;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<CartItem> cart;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<FavoriteProduct> favorite;

    public User() {

    }

    public User(Long id, UserRole role, String imagePath) {
        this(role, imagePath);
        this.id = id;
    }

    public User(UserRole role, String imagePath) {
        this.role = role;
        this.imagePath = imagePath;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public UserCredential getCredential() {
        return credential;
    }

    public void setCredential(UserCredential credential) {
        this.credential = credential;
    }

    public List<CartItem> getCart() {
        return cart;
    }


    public void setCart(List<CartItem> cart) {
        this.cart = cart;
    }

    public List<FavoriteProduct> getFavorite() {
        return favorite;
    }

    public void setFavorite(List<FavoriteProduct> favorite) {
        this.favorite = favorite;
    }
}
