package dao.model.user;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
