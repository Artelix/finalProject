package dao.model.comment;

import dao.model.order.Order;

import javax.persistence.*;

@Entity
@Table(name = "order_comments")
public class OrderComment extends BaseComment {
    @ManyToOne
    @JoinColumn(name = "orderId")
    private Order order;

    public OrderComment() {
    }
}
