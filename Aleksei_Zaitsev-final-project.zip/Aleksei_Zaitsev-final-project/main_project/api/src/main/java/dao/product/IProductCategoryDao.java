package dao.product;

import dao.IAbstractDao;
import dao.model.product.ProductCategory;

public interface IProductCategoryDao extends IAbstractDao<ProductCategory, Long> {
}
