package dao.cart;

import dao.IAbstractDao;
import exception.DBException;
import dao.model.cart.CartItem;

import java.util.List;

public interface ICartDao extends IAbstractDao<CartItem, Long> {
    List<CartItem> getCart(Long userId) throws DBException;
}
