package dao.order;

import dao.IAbstractDao;
import dao.model.order.Status;

public interface IStatusDao extends IAbstractDao<Status, Long> {
}
