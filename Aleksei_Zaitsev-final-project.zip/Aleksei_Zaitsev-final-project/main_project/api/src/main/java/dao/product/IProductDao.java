package dao.product;

import dao.IAbstractDao;
import exception.DBException;
import dao.model.product.Product;

import java.util.List;

public interface IProductDao extends IAbstractDao<Product, Long> {
    List<Product> listByCategory(Long categoryId) throws DBException;

    List<Product> searchByWord(String word) throws DBException;

    List<Product> getByPrices(double lowPrice, double highPrice) throws DBException;

    List<Product> getByRating(double lowRating, double highRating) throws DBException;

}
