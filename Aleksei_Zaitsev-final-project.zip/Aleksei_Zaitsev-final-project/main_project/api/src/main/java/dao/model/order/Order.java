package dao.model.order;

import dao.model.PickupPoint;
import dao.model.user.User;
import dao.model.comment.OrderComment;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "order")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column
    private Date createDate;

    @Column
    private String address;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    @ManyToOne
    @JoinColumn(name = "pickupPointId")
    private PickupPoint pickupPoint;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderComment> comments= new ArrayList<>();

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderStatus> statuses= new ArrayList<>();

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<OrderItem> products = new ArrayList<>();

    public Order() {
    }

    public OrderStatus getActualStatus() {
        return null;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public PickupPoint getPickupPoint() {
        return pickupPoint;
    }

    public void setPickupPoint(PickupPoint pickupPoint) {
        this.pickupPoint = pickupPoint;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<OrderComment> getComments() {
        return comments;
    }

    public void setComments(List<OrderComment> comments) {
        this.comments = comments;
    }

    public List<OrderStatus> getStatuses() {
        return statuses;
    }

    public void setStatuses(List<OrderStatus> statuses) {
        this.statuses = statuses;
    }

    public List<OrderItem> getProducts() {
        return products;
    }

    /*public void setProducts(List<OrderItem> products) {
        this.products = products;
    }*/

    public void addOrderItem(OrderItem item){
        item.setOrder(this);
        products.add(item);
    }

    public void addStatus(OrderStatus status) {
        statuses.add(status);
    }


}