package service.model;

import dao.model.order.OrderStatus;
import java.util.Date;

public class OrderStatusViewModel {
    private Long id;
    private Date date;
    private StatusViewModel status;

    public OrderStatusViewModel(){}

    public OrderStatusViewModel(OrderStatus orderStatus){
        this.id=orderStatus.getId();
        this.date=orderStatus.getDate();
        this.status=new StatusViewModel(orderStatus.getStatus());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public StatusViewModel getStatus() {
        return status;
    }

    public void setStatus(StatusViewModel status) {
        this.status = status;
    }
}
