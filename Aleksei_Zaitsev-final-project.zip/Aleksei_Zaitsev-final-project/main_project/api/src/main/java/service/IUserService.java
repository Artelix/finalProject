package service;

public interface IUserService {
    Long getUser(String login, String password);
}
