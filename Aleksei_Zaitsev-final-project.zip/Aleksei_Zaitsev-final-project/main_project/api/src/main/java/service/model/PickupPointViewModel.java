package service.model;


import dao.model.PickupPoint;

public class PickupPointViewModel {
    private Long id;
    private String address;
    private Double latitude;
    private Double longitude;
    private String description;

    public PickupPointViewModel(){

    }

    public PickupPointViewModel(PickupPoint pickupPoint) {
        this.id = pickupPoint.getId();
        this.address = pickupPoint.getAddress();
        this.latitude = pickupPoint.getLatitude();
        this.longitude = pickupPoint.getLongitude();
        this.description = pickupPoint.getDescription();
    }
}
