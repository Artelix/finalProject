package service.model;

import dao.model.favorite.FavoriteProduct;

public class FavoriteViewModel {
    private Long id;
    private Long productId;
    private String name;
    private double rating;
    private double price;
    private String imagePath;

    public FavoriteViewModel(){

    }

    public FavoriteViewModel(FavoriteProduct favoriteProduct) {
        this.productId = favoriteProduct.getProductId();
        this.name = favoriteProduct.getProductName();
        this.rating = favoriteProduct.getProductRating();
        this.price = favoriteProduct.getProductPrice();
        this.imagePath = favoriteProduct.getProductImagePath();
    }

    public Long getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public double getRating() {
        return rating;
    }

    public double getPrice() {
        return price;
    }

    public String getImagePath() {
        return imagePath;
    }
}
