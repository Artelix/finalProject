package service;

import service.model.ProductViewModel;

import java.util.List;

public interface IProductService {

    Boolean addProduct(String name,
                       Integer quantity,
                       Double price,
                       String imagePath,
                       String details,
                       Long categoryId);

    Boolean deleteProduct(Long productId);

    List<ProductViewModel> getListByCategory(Long productCategoryId);

    List<ProductViewModel> search(String word);

    ProductViewModel getDetails(Long id);

    List<ProductViewModel> getListByPrices(double lowPrice, double highPrice);

    List<ProductViewModel> getListByRating(double lowRating, double highRating);

}
