package service;

import service.model.FavoriteViewModel;

import java.util.List;

public interface IFavoriteService {
    Boolean addToFavorites(Long userId, Long productId);

    Boolean deleteFromFavorites(Long favoriteId);

    List<FavoriteViewModel> getFavoriteProducts(Long userId);
}
