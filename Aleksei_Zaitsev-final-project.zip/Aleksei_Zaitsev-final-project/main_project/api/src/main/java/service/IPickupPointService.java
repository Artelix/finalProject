package service;

import service.model.PickupPointViewModel;

import java.util.List;

public interface IPickupPointService {
    Boolean addPickupPoint(String address,
                           Double latitude,
                           Double longitude,
                           String description);

    Boolean deletePickupPoint(Long id);

    List<PickupPointViewModel> getAllPoints();
}
