package service;

import service.model.CartItemViewModel;

import java.util.List;

public interface ICartService {
    List<CartItemViewModel> getCart(Long userId);

    Boolean addToCart(Long userId, Long productId, Integer quantity);

    //TODO get cartItemId from user or use userId&productId
    Boolean deleteFromCart(Long cartItemId);
}
