package service.model;

import dao.model.cart.CartItem;

public class CartItemViewModel {
    private Long id;
    private Integer quantity;
    private ProductViewModel productViewModel;

    public CartItemViewModel() {
    }

    public CartItemViewModel(CartItem cartItem) {
        this.id = cartItem.getId();
        this.quantity = cartItem.getQuantity();
        this.productViewModel = new ProductViewModel(cartItem.getProduct());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public ProductViewModel getProductViewModel() {
        return productViewModel;
    }

    public void setProductViewModel(ProductViewModel productViewModel) {
        this.productViewModel = productViewModel;
    }
}
