package service;

import service.model.ProductCategoryViewModel;

import java.util.List;

public interface IProductCategoryService {
    List<ProductCategoryViewModel> getList();
}
