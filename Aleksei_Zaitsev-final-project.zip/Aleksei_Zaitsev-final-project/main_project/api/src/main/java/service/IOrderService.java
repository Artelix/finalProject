package service;

import service.model.StatusViewModel;

import java.util.List;

public interface IOrderService {
    Boolean createOrder(Long userId);

    Boolean addStatus(String statusName);

    Boolean deleteStatus(Long statusId);

    List<StatusViewModel> getStatusList();
}
