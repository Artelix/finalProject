package service.model;

import dao.model.order.Order;

import java.util.Date;

public class OrderViewModel {
    private Long id;
    private Date createDate;
    private String userName;
    private OrderStatusViewModel actualStatus;

    public OrderViewModel(){}

    public OrderViewModel(Order order){
        this.id=order.getId();
        this.createDate=order.getCreateDate();
        this.userName=order.getUser().getName();
        this.actualStatus=new OrderStatusViewModel(order.getActualStatus());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public OrderStatusViewModel getActualStatus() {
        return actualStatus;
    }

    public void setActualStatus(OrderStatusViewModel actualStatus) {
        this.actualStatus = actualStatus;
    }
}
