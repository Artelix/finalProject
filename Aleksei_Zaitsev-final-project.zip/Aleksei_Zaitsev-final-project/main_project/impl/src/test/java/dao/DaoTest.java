package dao;

import org.hibernate.*;
import org.junit.*;
import org.mockito.*;

import static org.mockito.Mockito.when;

public class DaoTest {
    @Mock
    protected SessionFactory sessionFactory;

    @Mock
    protected Session session;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        when(sessionFactory.getCurrentSession()).thenReturn(session);
    }
}
