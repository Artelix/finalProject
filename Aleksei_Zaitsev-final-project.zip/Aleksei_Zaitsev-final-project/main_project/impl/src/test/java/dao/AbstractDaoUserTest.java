package dao;

import dao.model.user.User;
import dao.model.user.UserRole;
import dao.user.IUserDao;
import dao.user.UserDao;
import exception.DBException;
import org.hibernate.Criteria;
import org.junit.*;
import org.mockito.*;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class AbstractDaoUserTest extends DaoTest {
    private User user;

    @InjectMocks
    private UserDao userDao;

    @Mock
    private Criteria criteria;

    @Before
    @Override
    public void init() {
        super.init();
        user = new User(UserRole.ADMIN, "");
    }

    @Test
    public void create() throws DBException {
        Long idExpected = 1L;

        when(sessionFactory.getCurrentSession().save(user)).thenReturn(1L);

        Long idActual = userDao.create(user);

        verify(sessionFactory.getCurrentSession()).save(user);

        Assert.assertEquals(idExpected, idActual);
    }

    @Test
    public void read() throws DBException {
        when(sessionFactory.getCurrentSession().get(User.class, 1L)).thenReturn(user);

        User userActual = userDao.read(1L);

        verify(sessionFactory.getCurrentSession()).get(User.class, 1L);

        Assert.assertEquals(user, userActual);
    }

    @Test
    public void update() throws DBException {
        Boolean result = userDao.update(user);

        verify(sessionFactory.getCurrentSession()).update(user);

        Assert.assertEquals(true, result);
    }

    @Test
    public void delete() throws DBException {
        when(sessionFactory.getCurrentSession().get(User.class, 1L)).thenReturn(user);

        Boolean result = userDao.delete(1L);

        verify(sessionFactory.getCurrentSession()).get(User.class, 1L);
        verify(sessionFactory.getCurrentSession()).delete(user);

        Assert.assertEquals(true, result);
    }

    @Test
    public void delete_NULL_ENTITY() throws DBException {
        when(sessionFactory.getCurrentSession().get(User.class, 1L)).thenReturn(null);

        Boolean result = userDao.delete(1L);

        verify(sessionFactory.getCurrentSession()).get(User.class, 1L);

        Assert.assertEquals(false, result);
    }

    @Test
    public void findAll() throws DBException {
        List<User> usersExpected = new ArrayList<User>();
        usersExpected.add(user);

        when(sessionFactory.getCurrentSession().createCriteria(User.class)).thenReturn(criteria);
        when(sessionFactory.getCurrentSession().createCriteria(User.class).list()).thenReturn(usersExpected);

        List<User> usersActual = userDao.findAll();

        verify(sessionFactory.getCurrentSession().createCriteria(User.class)).list();

        Assert.assertEquals(usersExpected, usersActual);
    }
}