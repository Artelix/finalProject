package dao;

import dao.model.user.*;
import dao.user.UserDao;
import exception.DBException;
import org.hibernate.query.Query;
import org.junit.*;
import org.mockito.*;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class UserDaoTest extends DaoTest {
    @InjectMocks
    private UserDao userDao;

    @Mock
    protected Query query;

    @Before
    @Override
    public void init() {
        super.init();
        when(sessionFactory.getCurrentSession().createQuery(any(String.class))).thenReturn(query);
    }

    @Test
    public void getUser() throws DBException {
        User userExpected = new User(UserRole.ADMIN, "");
        List<User> userList = new ArrayList<User>();
        userList.add(userExpected);

        when(query.getResultList()).thenReturn(userList);

        User userActual = userDao.getUser("admin", "admin");

        verify(sessionFactory.getCurrentSession()).createQuery(any(String.class));
        verify(query).getResultList();

        Assert.assertEquals(userExpected, userActual);
    }

    @Test
    public void getUser_NULL_ENTITY() throws DBException {
        List<User> userList = new ArrayList<User>();

        when(query.getResultList()).thenReturn(userList);

        User userActual = userDao.getUser("admin", "admin");

        verify(sessionFactory.getCurrentSession()).createQuery(any(String.class));
        verify(query).getResultList();

        Assert.assertEquals(null, userActual);
    }
}