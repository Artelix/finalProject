package service;

import dao.model.user.User;
import dao.model.user.UserRole;
import dao.user.IUserDao;
import exception.DBException;
import org.junit.*;
import org.mockito.*;

import static org.mockito.Mockito.*;

public class UserServiceTest {
    @InjectMocks
    private UserService userService;

    @Mock
    IUserDao userDao;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getUser() throws DBException {
        User user = new User(1L, UserRole.ADMIN, "");
        Long userIdExpected = user.getId();

        when(userDao.getUser(any(String.class), any(String.class))).thenReturn(user);

        Long userIdActual = userService.getUser("admin", "admin");

        verify(userDao).getUser(any(String.class), any(String.class));

        Assert.assertEquals(userIdExpected, userIdActual);
    }

    @Test
    public void getUser_NULL_ENTITY() throws DBException {
        when(userDao.getUser(any(String.class), any(String.class))).thenReturn(null);

        Long userIdActual = userService.getUser("admin", "admin");

        verify(userDao).getUser(any(String.class), any(String.class));

        Assert.assertEquals(null, userIdActual);
    }
}