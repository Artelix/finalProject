package service;

import dao.product.IProductCategoryDao;
import exception.DBException;
import dao.model.product.ProductCategory;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.model.ProductCategoryViewModel;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ProductCategoryService implements IProductCategoryService {
    final Logger logger = Logger.getLogger(ProductCategoryService.class);

    @Autowired
    private IProductCategoryDao productCategoryDao;

    @Override
    public List<ProductCategoryViewModel> getList() {
        try {
            List<ProductCategoryViewModel> list = new ArrayList<>();
            for (ProductCategory pc : productCategoryDao.findAll()) {
                list.add(new ProductCategoryViewModel(pc));
            }
            return list;
        } catch (DBException e) {
            logger.error(e);
            return null;
        }
    }
}
