package service;

import dao.model.product.ProductCategory;
import dao.product.IProductCategoryDao;
import dao.product.IProductDao;
import exception.DBException;
import dao.model.product.Product;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.model.ProductViewModel;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ProductService implements IProductService {
    final Logger logger = Logger.getLogger(ProductService.class);

    @Autowired
    private IProductDao productDao;

    @Autowired
    private IProductCategoryDao productCategoryDao;

    @Override
    public Boolean addProduct(String name,
                              Integer quantity,
                              Double price,
                              String imagePath,
                              String details,
                              Long categoryId) {
        try {
            if (productDao.checkForUnique("name", name)) {
                Product product= new Product(name,quantity,price,imagePath,details);
                product.setCategory(getProductCategory(categoryId));
                productDao.create(product);
                return true;
            }
        } catch (DBException e) {
            logger.error("Add product fail " + e);
            return false;
        }
        return false;
    }

    @Override
    public Boolean deleteProduct(Long productId) {
        try {
            productDao.delete(productId);
            return true;
        } catch (DBException e) {
            logger.error("Delete product fail " + e);
            return false;
        }
    }

    @Override
    public List<ProductViewModel> getListByCategory(Long productCategoryId) {
        try {
            return transformList(productDao.listByCategory(productCategoryId));
        } catch (DBException e) {
            logger.error("getListByCategory fail " + e);
            return null;
        }
    }

    @Override
    public List<ProductViewModel> search(String word) {
        try {
            return transformList(productDao.searchByWord(word));
        } catch (DBException e) {
            logger.error("search fail " + e);
            return null;
        }
    }

    @Override
    public ProductViewModel getDetails(Long id) {
        try {
            return new ProductViewModel(productDao.read(id));
        } catch (DBException e) {
            logger.error("getDetails fail " + e);
            return null;
        }
    }

    @Override
    public List<ProductViewModel> getListByPrices(double lowPrice, double highPrice) {
        try {
            return transformList(productDao.getByPrices(lowPrice, highPrice));
        } catch (DBException e) {
            logger.error("getListByPrices fail " + e);
            return null;
        }
    }

    @Override
    public List<ProductViewModel> getListByRating(double lowRating, double highRating) {
        try {
            return transformList(productDao.getByRating(lowRating, highRating));
        } catch (DBException e) {
            logger.error("getListByRating fail " + e);
            return null;
        }
    }



    private List<ProductViewModel> transformList(List<Product> products) {
        List<ProductViewModel> list = new ArrayList<>();
        for (Product p : products) {
            list.add(new ProductViewModel(p));
        }
        return list;
    }

    private ProductCategory getProductCategory(Long id){
        try {
            return productCategoryDao.read(id);
        } catch (DBException e) {
            logger.error("getProductCategory fail " + e);
        }
        return null;
    }
}
