package service;

import dao.cart.ICartDao;
import dao.product.IProductDao;
import dao.user.IUserDao;
import exception.DBException;
import dao.model.cart.CartItem;
import dao.model.product.Product;
import dao.model.user.User;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.model.CartItemViewModel;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class CartService implements ICartService {
    final Logger logger = Logger.getLogger(ProductService.class);

    @Autowired
    private IUserDao userDao;

    @Autowired
    private ICartDao cartDao;

    @Autowired
    private IProductDao productDao;

    @Override
    public List<CartItemViewModel> getCart(Long userId) {
        List<CartItemViewModel> list = new ArrayList<>();
        try {
            for(CartItem ci : cartDao.getCart(userId)){
                list.add(new CartItemViewModel(ci));
            }
            return list;
        } catch (DBException e) {
            logger.error("Get user's cart fail " + e);
            return null;
        }
    }

    @Override
    public Boolean addToCart(Long userId, Long productId, Integer quantity) {
        try {
            User user = userDao.read(userId);
            Product product = productDao.read(productId);

            if (user != null
                    && product != null
                    && product.getQuantity() >= quantity) {
                CartItem checkedItem = checkCart(userId, productId);
                if (checkedItem != null) {
                    checkedItem.setQuantity(checkedItem.getQuantity() + quantity);
                    cartDao.update(checkedItem);
                } else {
                    CartItem cartItem = new CartItem(user,product,quantity);
                    cartDao.create(cartItem);
                }
                return true;
            }
        } catch (DBException e) {
            logger.error("Add item to cart fail" + e);
        }
        return false;
    }

    @Override
    public Boolean deleteFromCart(Long cartItemId) {
        try {
            return cartDao.delete(cartItemId);
        } catch (DBException e) {
            logger.error("Delete item fail" + e);
        }
        return false;
    }

    private CartItem checkCart(Long userId, Long productId) {
        try {
            for (CartItem item : cartDao.getCart(userId)) {
                if (item.getProductId().equals(productId)) {
                    return item;
                }
            }
        } catch (DBException e) {
            logger.error("Get list fail" + e);
        }
        return null;
    }
}
