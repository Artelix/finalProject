package service;

import dao.favorite.IFavoriteProductDao;
import dao.product.IProductDao;
import dao.user.IUserDao;
import exception.DBException;
import dao.model.favorite.FavoriteProduct;
import dao.model.product.Product;
import dao.model.user.User;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.model.FavoriteViewModel;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class FavoriteService implements IFavoriteService {
    private final Logger logger = Logger.getLogger(FavoriteService.class);

    @Autowired
    private IFavoriteProductDao favoriteProductDao;

    @Autowired
    private IProductDao productDao;

    @Autowired
    private IUserDao userDao;

    @Override
    public Boolean addToFavorites(Long userId, Long productId) {
        try {
            User user = userDao.read(userId);
            if (favoriteProductDao.checkForUnique(userId, productId)) {
                Product product = productDao.read(productId);
                favoriteProductDao.create(new FavoriteProduct(user, product));
                return true;
            } else return false;
        } catch (DBException e) {
            logger.error("Add favorite product fail " + e);
            return false;
        }
    }

    @Override
    public Boolean deleteFromFavorites(Long favoriteId) {
        try {
            favoriteProductDao.delete(favoriteId);
            return true;
        } catch (DBException e) {
            logger.error("Delete favorite product fail " + e);
            return false;
        }
    }

    @Override
    public List<FavoriteViewModel> getFavoriteProducts(Long userId) {
        try {
            List<FavoriteViewModel> list = new ArrayList<>();
            for (FavoriteProduct fp : favoriteProductDao.getFavoriteProducts(userId)) {
                list.add(new FavoriteViewModel(fp));
            }
            return list;
        } catch (DBException e) {
            logger.error("Get user's favorite products fail " + e);
            return null;
        }
    }
}
