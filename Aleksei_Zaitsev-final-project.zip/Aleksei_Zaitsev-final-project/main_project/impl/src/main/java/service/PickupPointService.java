package service;

import dao.model.PickupPoint;
import dao.pickup_point.IPickupPointDao;
import exception.DBException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.model.PickupPointViewModel;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class PickupPointService implements IPickupPointService {
    private final Logger logger = Logger.getLogger(PickupPointService.class);

    @Autowired
    private IPickupPointDao pickupPointDao;

    @Override
    public Boolean addPickupPoint(String address,
                                  Double latitude,
                                  Double longitude,
                                  String description) {
        PickupPoint pickupPoint = new PickupPoint(address, latitude, longitude, description);
        if (checkForUnique("address",address)){
            try {
                pickupPointDao.create(pickupPoint);
                return true;
            } catch (DBException e) {
                logger.error("Add pickup point fail " + e);
            }
        }
        return false;
    }

    @Override
    public Boolean deletePickupPoint(Long id) {
        try {
            pickupPointDao.delete(id);
            return true;
        } catch (DBException e) {
            logger.error("Delete pickup point fail " + e);
            return false;
        }
    }

    @Override
    public List<PickupPointViewModel> getAllPoints() {
        return prepareViewList(getList());
    }

    private Boolean checkForUnique(String columnName, String value){
        try {
            return pickupPointDao.checkForUnique(columnName,value);
        } catch (DBException e) {
            logger.error("Checking for unique fail " + e);
            return false;
        }
    }

    private List<PickupPoint> getList() {
        List<PickupPoint> list = null;
        try {
            list = pickupPointDao.findAll();
        } catch (DBException e) {
            logger.error("Get all points fail " + e);
        }
        return list;
    }

    private List<PickupPointViewModel> prepareViewList(List<PickupPoint> list) {
        List<PickupPointViewModel> viewModels = new ArrayList<>();
        for (PickupPoint p : list) {
            viewModels.add(new PickupPointViewModel(p));
        }
        return viewModels;
    }


}
