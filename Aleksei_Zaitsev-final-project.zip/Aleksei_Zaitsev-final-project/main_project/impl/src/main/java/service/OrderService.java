package service;

import dao.cart.ICartDao;
import dao.model.cart.CartItem;
import dao.model.order.Order;
import dao.model.order.OrderItem;
import dao.model.order.Status;
import dao.model.product.Product;
import dao.order.IOrderDao;
import dao.order.IStatusDao;
import dao.user.IUserDao;
import exception.DBException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.model.StatusViewModel;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class OrderService implements IOrderService {
    final Logger logger = Logger.getLogger(OrderService.class);

    @Autowired
    private IOrderDao orderDao;

    @Autowired
    private IStatusDao statusDao;

    @Autowired
    private ICartDao cartDao;

    @Autowired
    private IUserDao userDao;

    @Override
    public Boolean createOrder(Long userId) {
        Order order = new Order();
        try {
            order.setUser(userDao.read(userId));
        } catch (DBException e) {
            logger.error("read user fail " + e);
        }
        List<CartItem> cartItems = getCartItems(userId);
        //List<OrderItem> list = prepareOrderItems(cartItems);
        /*for(OrderItem oi : list){
            oi.setOrder(order);
        }
        order.setProducts(list);*/
        OrderItem orderItem = new OrderItem();
        orderItem.setProduct(cartItems.get(0).getProduct());
        orderItem.setQuantity(1);
        order.addOrderItem(orderItem);

        logger.error(" list have been set");
        try {
            orderDao.persist(order);
            orderDao.create(order);
            return true;
        } catch (DBException e) {
            logger.error("createOrder fail " + e);
        }
        return false;
    }

    @Override
    public Boolean addStatus(String statusName) {
        try {
            if (statusDao.checkForUnique("name", statusName)) {
                Status newStatus = new Status(statusName);
                statusDao.create(newStatus);
                return true;
            }
        } catch (DBException e) {
            logger.error("addStatus fail " + e);
        }
        return false;
    }

    @Override
    public Boolean deleteStatus(Long statusId) {
        try {
            statusDao.delete(statusId);
            return true;
        } catch (DBException e) {
            logger.error("deleteStatus fail " + e);
        }
        return false;
    }

    @Override
    public List<StatusViewModel> getStatusList() {
        try {
            return prepareStatusViewList(statusDao.findAll());
        } catch (DBException e) {
            logger.error("getStatusList fail " + e);
        }
        return null;
    }

    private List<StatusViewModel> prepareStatusViewList(List<Status> list) {
        List<StatusViewModel> viewModels = new ArrayList<>();
        for (Status s : list) {
            viewModels.add(new StatusViewModel(s));
        }
        return viewModels;
    }

    private List<CartItem> getCartItems(Long userId) {
        try {
            return cartDao.getCart(userId);
        } catch (DBException e) {
            logger.error("getCartItems fail " + e);
        }
        return null;
    }

    private List<OrderItem> prepareOrderItems(List<CartItem> list) {
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem ci : list) {
            if (checkQuantity(ci)) {
                orderItems.add(new OrderItem(ci));
                changeProductQuantity(ci);
            }
        }
        return orderItems;
    }

    private Boolean checkQuantity(CartItem cartItem) {
        Integer quantity = cartItem.getQuantity();
        Integer productQuantity = cartItem.getProduct().getQuantity();
        if (productQuantity >= quantity) return true;
        else return false;
    }

    private void changeProductQuantity(CartItem cartItem) {
        Product product = cartItem.getProduct();
        Integer quantity = product.getQuantity();
        product.setQuantity(quantity - cartItem.getQuantity());
    }

}
