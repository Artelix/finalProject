package service;

import dao.user.IUserDao;
import exception.DBException;
import dao.model.user.User;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class UserService implements IUserService {
    final Logger logger = Logger.getLogger(UserService.class);

    @Autowired
    private IUserDao userDao;

    @Override
    public Long getUser(String login, String password) {
        try {
            User user = userDao.getUser(login, password);
            return user != null ? user.getId() : null;
        } catch (DBException e) {
            logger.error(e);
            return null;
        }
    }
}
