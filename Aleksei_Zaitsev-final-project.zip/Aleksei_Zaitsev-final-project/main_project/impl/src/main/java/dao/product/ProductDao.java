package dao.product;

import dao.AbstractDao;
import exception.DBException;
import dao.model.product.Product;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ProductDao extends AbstractDao<Product, Long> implements IProductDao {
    public ProductDao() {
        super(Product.class);
    }

    @Override
    public List<Product> listByCategory(Long categoryId) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select p from Product p join p.category c where c.id=:categoryId");
            query.setParameter("categoryId", categoryId);
            List<Product> list = query.getResultList();

            return list;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get product list error");
        }
    }

    @Override
    public List<Product> searchByWord(String word) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select p from Product p where p.name like '%" + word + "%'");
            List<Product> list = query.getResultList();

            return list;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Search products error");
        }
    }

    @Override
    public List<Product> getByPrices(double lowPrice, double highPrice) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select p from Product p where p.price between :lowPrice and :highPrice");
            query.setParameter("lowPrice", lowPrice);
            query.setParameter("highPrice", highPrice);
            List<Product> list = query.getResultList();

            return list;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get product list error");
        }
    }

    @Override
    public List<Product> getByRating(double lowRating, double highRating) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select p from Product p where p.rating between :lowRating and :highRating");
            query.setParameter("lowRating", lowRating);
            query.setParameter("highRating", highRating);
            List<Product> list = query.getResultList();

            return list;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get product list error");
        }
    }

}
