package dao.cart;

import dao.AbstractDao;
import exception.DBException;
import dao.model.cart.CartItem;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CartDao extends AbstractDao<CartItem, Long> implements ICartDao {
    public CartDao() {
        super(CartItem.class);
    }

    @Override
    public List<CartItem> getCart(Long userId) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select ci from CartItem ci join ci.user u where u.id=:userId");
            query.setParameter("userId", userId);
            List<CartItem> list = query.getResultList();

            return list;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get cart error");
        }
    }
}
