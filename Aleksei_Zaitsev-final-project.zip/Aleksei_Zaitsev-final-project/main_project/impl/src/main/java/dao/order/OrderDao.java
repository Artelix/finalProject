package dao.order;

import dao.AbstractDao;
import dao.model.order.Order;
import org.springframework.stereotype.Repository;

@Repository
public class OrderDao extends AbstractDao<Order, Long> implements IOrderDao {
    public OrderDao() {
        super(Order.class);
    }

}
