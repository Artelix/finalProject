package dao.product;

import dao.AbstractDao;
import dao.model.product.ProductCategory;
import org.springframework.stereotype.Repository;

@Repository
public class ProductCategoryDao extends AbstractDao<ProductCategory, Long> implements IProductCategoryDao {
    public ProductCategoryDao() {
        super(ProductCategory.class);
    }
}
