package dao.user;

import dao.AbstractDao;
import exception.DBException;
import dao.model.user.User;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDao extends AbstractDao<User, Long> implements IUserDao {

    public UserDao() {
        super(User.class);
    }

    @Override
    public User getUser(String login, String password) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select u from User u join u.credential c where c.login='" + login + "' and c.password='" + password + "'");
            List<User> list = query.getResultList();

            return list.isEmpty() ? null : list.iterator().next();
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get entity error");
        }
    }
}
