package dao.favorite;

import dao.AbstractDao;
import exception.DBException;
import dao.model.favorite.FavoriteProduct;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FavoriteProductDao extends AbstractDao<FavoriteProduct, Long> implements IFavoriteProductDao {
    public FavoriteProductDao() {
        super(FavoriteProduct.class);
    }

    @Override
    public List<FavoriteProduct> getFavoriteProducts(Long userId) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select fp from FavoriteProduct fp join fp.user u where u.id=:userId");
            query.setParameter("userId", userId);
            List<FavoriteProduct> list = query.getResultList();
            return list;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get favorite products error" + ex);
        }
    }

    @Override
    public Boolean checkForUnique(Long userId, Long productId) throws DBException {
        try {
            Query query = sessionFactory.getCurrentSession().createQuery("select fp from FavoriteProduct fp join fp.user u join fp.product p where u.id=:userId and p.id=:productId");
            query.setParameter("userId", userId);
            query.setParameter("productId", productId);
            List<FavoriteProduct> list = query.getResultList();
            return list.isEmpty();
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get favorite products error" + ex);
        }
    }
}
