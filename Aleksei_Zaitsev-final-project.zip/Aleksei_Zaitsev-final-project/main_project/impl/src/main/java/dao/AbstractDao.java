package dao;

import exception.DBException;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.Serializable;
import java.util.List;

@Repository
public abstract class AbstractDao<T, PK extends Serializable> implements IAbstractDao<T, PK> {

    private Class<T> type;
    protected final Logger logger = Logger.getLogger(AbstractDao.class);

    @Autowired
    protected SessionFactory sessionFactory;

    public AbstractDao(Class<T> type) {
        this.type = type;
    }

    @Override
    public PK create(T entity) throws DBException {
        try {
            return (PK) sessionFactory.getCurrentSession().save(entity);
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Create entity error" + ex);
        }
    }

    @Override
    public Boolean persist(T entity) throws DBException {
        try {
            sessionFactory.getCurrentSession().persist(entity);
            return true;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Create entity error" + ex);
        }
    }

    @Override
    public T read(PK id) throws DBException {
        try {
            return sessionFactory.getCurrentSession().get(type, id);
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Read entity error");
        }
    }

    @Override
    public Boolean update(T entity) throws DBException {
        try {
            sessionFactory.getCurrentSession().update(entity);
            return true;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Update entity error");
        }
    }

    @Override
    public Boolean delete(PK id) throws DBException {
        try {
            T entity = sessionFactory.getCurrentSession().get(type, id);
            if (entity != null) {
                sessionFactory.getCurrentSession().delete(entity);
                return true;
            }
            return false;
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Delete entity error");
        }
    }

    @Override
    public List<T> findAll() throws DBException {
        try {
            return sessionFactory.getCurrentSession().createCriteria(type).list();
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Get all error" + ex);
        }
    }

    @Override
    public Boolean checkForUnique(String columnName, String value) throws DBException {
        try {
            return getCheckList(getCriteriaQuery(columnName, value)).isEmpty();
        } catch (Exception ex) {
            logger.error(ex);
            throw new DBException("Check for unique error");
        }
    }

    private List<T> getCheckList(CriteriaQuery<T> criteriaQuery) throws Exception {
        List<T> list = null;
        list = sessionFactory.getCurrentSession().createQuery(criteriaQuery).getResultList();
        return list;
    }

    private CriteriaQuery<T> getCriteriaQuery(String columnName, String value) {
        CriteriaBuilder cb = sessionFactory.getCriteriaBuilder();
        CriteriaQuery<T> criteriaQuery = cb.createQuery(type);
        Root<T> root = criteriaQuery.from(type);
        criteriaQuery.select(root);
        return criteriaQuery.where(cb.equal(root.get(columnName), value));
    }
}
