package dao.order;

import dao.AbstractDao;
import dao.model.order.Status;
import org.springframework.stereotype.Repository;

@Repository
public class StatusDao extends AbstractDao<Status, Long> implements IStatusDao {
    public StatusDao() {
        super(Status.class);
    }
}
