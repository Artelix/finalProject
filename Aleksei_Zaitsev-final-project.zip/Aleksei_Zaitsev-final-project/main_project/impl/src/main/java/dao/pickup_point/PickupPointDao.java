package dao.pickup_point;

import dao.AbstractDao;
import dao.model.PickupPoint;
import org.springframework.stereotype.Repository;


@Repository
public class PickupPointDao extends AbstractDao<PickupPoint, Long> implements IPickupPointDao {
    public PickupPointDao() {
        super(PickupPoint.class);
    }
}
